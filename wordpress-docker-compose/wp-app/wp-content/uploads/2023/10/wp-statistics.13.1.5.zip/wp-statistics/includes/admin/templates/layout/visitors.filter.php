<div id="visitors-filter-popup" dir="<?php echo(is_rtl() ? 'rtl' : 'ltr') ?>" style="display:none;">
    <form action="<?php echo admin_url('admin.php'); ?>" method="get" id="wp_statistics_visitors_filter_form">
        <input type="hidden" name="page" value="<?php echo $pageName; ?>">

        <div id="wps-visitors-filter-form">
            <!-- DO JS -->
        </div>
    </form>
</div>
