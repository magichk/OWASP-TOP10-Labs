<p class="ps_settings_subtitle"><?php echo $row['input']['content'] ?></p>
