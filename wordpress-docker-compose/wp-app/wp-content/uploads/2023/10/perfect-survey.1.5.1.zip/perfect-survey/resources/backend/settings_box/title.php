<div class="ps_title_section">
  <h3><?php echo $row['input']['content'] ?></h3>
</div>
