<div class="survey_answer_box">
  <textarea  name="ps_questions[<?php echo $question['question_id'];?>][]" placeholder="<?php _e('Insert an answer', 'perfect-survey') ?>" placeholder="<?php _e('Type your answer here...');?>"></textarea>
</div>
