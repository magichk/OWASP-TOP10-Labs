<?php
/*
Plugin Name: Perfect Survey
Plugin URI:  https://www.getperfectsurvey.com/
Description: Insert in your WordPress a perfect survey plugin
Version: 1.5.1
Author: Webaid
Author URI: https://www.getperfectsurvey.com/
Copyright: Vincenzo Migliano
Text Domain: perfect-survey

*/

$ps = require_once dirname(__FILE__).'/ps-bootstrap.php';

$ps->run();
